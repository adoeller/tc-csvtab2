# Migrationsstatus

## Erster produktiver Schnitt

- Lazarus/FPC-Projektgeruest fuer Win32 und Win64 angelegt.
- WLX-Exporte `ListLoad`, `ListLoadW`, `ListCloseWindow`,
  `ListGetDetectString`, `ListSetDefaultParams`, `ListSearchText` und
  `ListSearchTextW` angelegt.
- Plugin-lokale `csvtab.ini` hat Vorrang vor dem von Total Commander
  gelieferten Standardpfad.
- Eigener INI-Leser unterstuetzt Zeilenkommentare und Inline-Kommentare mit
  `;` und `#`, ohne gequotete Werte, URLs oder literale Delimiter zu zerstoeren.
- CSV-Modell mit Encoding-/BOM-Erkennung, Zell-Lexemen und Quellbereichen.
- Erste Parserunterstuetzung fuer Delimitererkennung, Quotes, doppelte Quotes,
  Multiline-Zellen und die drei Kommentarzeilenmodi.
- Natuerliche Sortierung und gleichmaessige Spalten-Stichprobe als getrennte
  wiederverwendbare Units uebernommen.
- UI-unabhaengiges Gridmodell mit getrennten sichtbaren Quellzeilen,
  kombinierbaren Spaltenfiltern und stabiler natuerlicher Sortierung.
- Nativer Win32-Viewer mit virtuellem Owner-Data-ListView, CSV-Headern,
  Statuszeile, Spaltenklick-Sortierung und WLX-Zellensuche vorwaerts/rueckwaerts.
- Automatische Spaltenbreite misst Header und gleichmaessig verteilte
  sichtbare Zeilen mit dem aktiven Grid-Font und beachtet die INI-Grenzen.
- Native Filterzeile im Header mit je einem Eingabefeld pro Spalte,
  konfigurierbarer Ausrichtung und unmittelbarer Aktualisierung des Grids.
- `Esc` in einem Filterfeld setzt nur den Fokus zurueck in die Tabelle und
  wird nicht an Total Commander zum Schliessen weitergegeben.
- Custom Draw fuer aktuelle Zelle, Mehrfachauswahl und alternierende
  Zeilenfarben; helle und dunkle INI-Farben werden angewendet.
- `Esc` sowie `1..8` werden wie im Original an Total Commander weitergereicht;
  Filterfelder behalten Zifferneingaben. Tabelle und Header besitzen getrennte
  INI-Farben, die Tabellenschrift verwendet Normalgewicht.
- `Ctrl+F`, `F3` und `Shift+F3` verwenden Total Commanders WLX-Suchfunktionen:
  Der Host liefert Suchtext und Optionen ueber `ListSearchTextW`; F3 sucht ab
  dem aktuellen Treffer vorwaerts und Shift+F3 rueckwaerts. Richtungswechsel,
  Gross-/Kleinschreibung und Ganzwortsuche behalten einen konsistenten
  Suchzustand.
- Klickbare Statusmenues schalten Encoding, Delimiter und Kommentarmodus um
  und laden Dokument, Grid, Filter und Status gemeinsam neu.
- Alle Original-INI-Schluessel sind wirksam: unquoted Trimming, Kopiermodus
  und Zeilentrennzeichen sowie `N`/`P`/`Q`-Weiterleitung wurden vervollstaendigt.
- Die Beispiel-INI enthaelt alle 36 im C-Original verwendeten Schluessel mit
  den Original-Defaults; der maschinelle Abgleich meldet keine fehlenden Keys.
- Das schnelle Editiermuster aus `wlx_xmltab` ist uebernommen: `Ctrl+R`
  schaltet den Editiermodus, `F2` oder Doppelklick oeffnet einen nativen
  Inline-Editor direkt ueber der Owner-Data-Zelle; Enter/Fokusverlust
  uebernimmt und Escape verwirft.
- Zellbearbeitungen referenzieren sichtbare Zeilen zurueck auf Quellzeilen,
  patchen nur das betroffene CSV-Lexem, erhalten erforderliche Quotes und
  passen nachfolgende Quellbereiche an. Grid, Filter, Sortierung und
  Dirty-Status werden danach konsistent aktualisiert.
- `Ctrl+S` speichert den gepatchten Quelltext atomar im urspruenglichen
  Encoding und mit dem urspruenglichen BOM. Vor dem Ersetzen wird die
  temporaere Datei mit denselben CSV-Regeln erneut geladen und auf
  Quelltext-, Encoding- und BOM-Gleichheit geprueft.
- ANSI-Speichern lehnt nicht verlustfrei darstellbare Zeichen ab. Fehler
  lassen die bestehende Zieldatei und den Dirty-Status unveraendert.
- `WM_CLOSE`, exportiertes `ListCloseWindow` sowie Encoding-, Delimiter- und
  Kommentarmoduswechsel fragen bei Dirty-Status mit Ja/Nein nach. Speichern
  oder Reload werden bei Fehler abgebrochen.
- Das in `wlx_xmltab` bewaehrte Grid-Kontextmenue ist uebernommen: Zelle,
  Zeilen und Spalte kopieren, Spalte ausblenden, alle Spalten wieder
  einblenden, Filter/Header/Editiermodus/Theme schalten und speichern.
- `Ctrl+Klick` auf einen Spaltenheader blendet die Spalte aus, `Ctrl+Space`
  zeigt alle Spalten wieder. Versteckte Spalten bleiben auch bei Filterung,
  Sortierung und automatischer Breitenberechnung verborgen.
- Filterzeile, Headerzeile und Dark Theme lassen sich zur Laufzeit schalten
  und werden unmittelbar in der INI gespeichert; Themewechsel zeichnet Grid,
  Header, Filter und Status neu.
- Die Header-Custom-Draw-Nachrichten werden vom ListView an den Viewer
  weitergereicht. Dadurch verwendet auch die Headerzeile im Darkmode
  verlaesslich die konfigurierten Headerfarben.
- Der neue Kontextmenue-Modus `Transform` oeffnet eine Sidebar mit den
  Spalten untereinander. Dort lassen sich Spalten verschieben, hinzufuegen,
  entfernen und umbenennen sowie Konstanten, Leerwert-Fuellung und
  Enumeration festlegen.
- Der INI-Schluessel `start-mode` legt mit `default`, `editor` oder
  `transformer` fest, in welchem Modus das Plugin startet. Unbekannte Werte
  fallen auf den normalen Default-Modus zurueck.
- Transform-Konfigurationen werden im mit `CSVtransform.pyw` kompatiblen
  JSON-Schema geladen und gespeichert. Export-Trenner und Zahlenformat sind
  in der Sidebar umschaltbar; `Export CSV` erzeugt eine transformierte
  UTF-8-Datei, ohne die Quelldatei zu veraendern.
- Alt-Klick auf eine Zelle oeffnet wie im Original eingebettete URLs oder
  punkt-haltige Domainwerte ueber `ShellExecute`; die URL-Erkennung ist als
  getrennte testbare Unit umgesetzt.
- `Ctrl+Mausrad` sowie `Ctrl++`/`Ctrl+-` zoomen die Tabellenschrift im
  Originalbereich 10 bis 48 Punkt. Grid, Filter und aktiver Editor werden
  aktualisiert und `font-size` wird gespeichert.
- Die automatische Spaltenbreite wird genau einmal beim Start festgelegt.
  Filtern, Sortieren, Editieren, Zoomen und Reload veraendern vorhandene
  Breiten nicht; nur die explizite Aktion `Show all columns` misst neu.
- `F1` oeffnet die Wiki-Hilfe des Originalprojekts.
- Wie beim Original von `wlx_jsontab` setzt `ListLoad`/`ListLoadW` den Fokus
  nach dem vollstaendigen Aufbau auf das erste Inhaltsfenster, bei csvtab also
  auf die Tabelle. Die Start-Hotkey-Sperre verhindert dabei weiterhin, dass
  die Aufruftaste an Total Commander zurueckgespiegelt wird.
- Das Hauptfenster wird sofort sichtbar in der aktuellen Clientgroesse des
  von Total Commander uebergebenen Lister-Fensters erstellt. Dadurch ist
  bereits das erste sichtbare Layout korrekt; spaetere Groessenaenderungen
  bleiben weiterhin unter Kontrolle von Total Commander.
- `ListLoad` und die Weitergabe von `Esc`, `1..8`, `N`, `P` und `Q` setzen
  keinen TC-Fokus mehr. Weitergegebene Tasten erzeugen genau eine direkte
  `WM_KEYDOWN`-Nachricht und keine zusaetzliche Zeichen- oder Fokusnachricht.
- Die Taste, mit der das Plugin geoeffnet oder im Lister ausgewaehlt wurde,
  wird nicht mehr an Total Commander zurueckgespiegelt: Hotkeys werden in der
  Startphase gesperrt und danach nur weitergegeben, wenn der Fokus
  tatsaechlich innerhalb des Plugins liegt. Dadurch kann der Pluginaufruf
  kein erneutes Einlesen beider TC-Panels mehr ausloesen.
- Das aeussere Pluginfenster verwendet `WS_EX_NOPARENTNOTIFY`. Dadurch
  erhaelt Total Commander beim Erzeugen des Viewers keine `WM_PARENTNOTIFY`,
  die zuvor ein Neueinlesen beider Panels ausloesen konnte.
- Die Headerbeschriftung wird bei sichtbarer Filterzeile nur im oberen
  Beschriftungsbereich vertikal zentriert und sitzt dadurch nicht mehr zu tief.
- Die Filterfelder sind keine native `HDS_FILTERBAR` mehr, sondern eine
  eigenstaendige Zeile oberhalb des ListView-Headers. Der Header bleibt ein
  nativer Header und behaelt Sortierung und Spaltenbreiten.
- Die Filterfelder sind wieder normale einzeilige Windows-Edits ohne eigenes
  Textformatierungsrechteck oder nachtraegliche Rahmenzeichnung. Die zuvor
  26 Pixel hohe Filterzeile ist um 2 Pixel auf 24 Pixel reduziert.
- Die Spaltenreihenfolge ist fest und kann nicht mehr per Header-Drag
  verschoben werden. Der Header verwendet eine eigene fette Schrift; sein
  heller Standardhintergrund ist RGB(204, 204, 204). Das Custom Draw zeichnet
  rechte Zellkanten und eine untere Headerkante, sodass die Spalten auch im
  Header sichtbar getrennt bleiben.
- Beim Ziehen einer Spaltenbreite verarbeitet das native ListView die
  Header-Benachrichtigungen wieder selbst. Grid und Filterfelder werden
  waehrend des Ziehens unmittelbar neu positioniert und gezeichnet.
- Die Filterfelder reagieren auch auf die laufenden Header-Tracking-
  Nachrichten und werden nach jeder Positionsaenderung sofort neu gezeichnet.
  Dadurch bleiben sie beim Ziehen einer Spaltenbreite synchron sichtbar.
- Beim ersten Anzeigen einer Datei wird die Breite der optionalen
  Zeilennummernspalte direkt aus der groessten sichtbaren Zeilennummer
  berechnet. Sie ist damit unabhaengig von der Stichprobe fuer Datenspalten.
- Beim erneuten Einlesen ueber `Delimiter` oder `Comments` in der Statusleiste
  bleibt die beim ersten Anzeigen bestimmte Breite der Zeilennummernspalte
  unveraendert erhalten.
- Leerzeilen, Zeilen deren erstes Zeichen `#` ist, Semikolon-Kommentarzeilen
  mit genau einem Semikolon am Zeilenanfang sowie `sep=`-Zeilen werden bei der
  automatischen Delimitererkennung immer uebersprungen, unabhaengig vom
  gewaehlten Kommentarmodus.
- Die automatische Delimitererkennung bewertet mehrere logische CSV-Zeilen
  nach einem konsistenten Trennzeichen. Einzelne Praeambelzeilen wie
  `;kommentar` koennen dadurch die folgende kommagetrennte Tabelle nicht mehr
  auf Semikolon umstellen.
- Das Delimiter-Menue der Statuszeile besitzt `Auto`. Der automatische Modus
  erkennt den Delimiter bei jedem Reload neu; die Statuszeile zeigt daneben
  das aktuell erkannte Zeichen.
- Das `Comments`-Menue verwendet reine Textbeschriftungen ohne numerische
  Praefixe. `Auto` blendet eine fuehrende Praeambel aus `#`-/`;`-
  Kommentarzeilen und Leerzeilen aus, behaelt solche Zeilen innerhalb der
  eigentlichen Tabelle aber bei. `skip-comments=3` startet in diesem Modus.
- `Parse normally`, `Do not parse`, `Hide` und `Auto` laden bei aktivem
  Delimiter-`Auto` alle mit derselben automatischen Erkennung wie beim ersten
  Laden neu. Nach jedem Reload werden auch Delimiter- und Comments-Anzeige der
  Statuszeile unmittelbar aktualisiert. Nach einem Wechsel des Comments-Modus
  werden die Spaltenbreiten erneut automatisch bestimmt.
- Zeilen, deren erstes Zeichen `#` ist, Semikolon-Kommentarzeilen mit genau
  einem Semikolon am Zeilenanfang sowie Zeilen, die mit `sep=` beginnen,
  gelten als Kommentarzeilen. `sep=` wird ohne Beachtung der
  Gross-/Kleinschreibung erkannt und bei der Delimitererkennung uebersprungen.
  Datenzeilen wie `;ghost;12;3` gelten wegen der weiteren Semikola nicht als
  Kommentar. `Comments: hidden` entfernt Kommentarzeilen sowie echte
  Leerzeilen. Die anderen Comments-Modi behalten Leerzeilen sichtbar.
- `decimal-align=1` richtet erkannte Dezimalzahlen mit `,` oder `.` innerhalb
  jeder Spalte am Dezimaltrennzeichen aus. Integer-Zellen in gemischten
  Integer-/Float-Spalten enden unmittelbar vor diesem Dezimalanker; reine
  Integer-Spalten werden rechtsbuendig dargestellt. Nichtnumerische Werte
  behalten ihre normale Darstellung.

## Erfolgreich gebaut und getestet

- `Release 64`: `csvtab.wlx64`
- `Release 32`: `csvtab.wlx`
- `settings_test.lpr`: 51/51 Pruefungen bestanden
- `decimal_align_test.lpr`: 14/14 Pruefungen bestanden
- `csv_model_test.lpr`: 63/63 Pruefungen bestanden
- `csv_save_test.lpr`: 38/38 Pruefungen bestanden
- `grid_model_test.lpr`: 14/14 Pruefungen bestanden
- `column_sample_test.lpr`: 7/7 Pruefungen bestanden
- `url_tools_test.lpr`: 5/5 Pruefungen bestanden
- `transform_test.lpr`: 10/10 Pruefungen bestanden
- `wlx_load_test.lpr`: echtes `ListLoadW` fokussiert das Grid, sendet keine
  Aufruftaste an den Host zurueck, gibt Hotkeys erst nach der Startphase
  weiter und prueft F3-Weiterleitung sowie Vorwaerts-/Rueckwaertssuche; die
  Startmodi `default`, `editor` und `transformer` sowie die Transform-Sidebar
  werden ebenfalls geprueft. Dezimalwerte mit Punkt und Komma durchlaufen
  dabei den Owner-Draw-Pfad. Ein separater Lauf mit 123 sichtbaren Zeilen
  bestaetigt die beim ersten Anzeigen berechnete Breite der Zeilennummern.
- `railroad_viewer_test.lpr`: laedt `US CA Railroad Channels.csv` ueber den
  echten `ListLoadW`-Pfad und prueft `Auto (,)`, den Header `Location` sowie
  `1` als erste sichtbare Datenzelle. Die fuehrende Kommentar- und Leerzeile
  gelangen damit nicht in die Tabelle.
- Builds und Tests wurden auch direkt im Zielprojekt `..\wlx_csvtab`
  ausgefuehrt.

## Noch offen
- Headerzellen im Editiermodus.
- Integrationstest fuer Inline-Editieren, Speichern und Dirty-Abfrage in
  Total Commander.
