# csvtab (extended)

A [Total Commander](https://www.ghisler.com/) Lister (WLX) plugin to view,
filter, search, **edit** and **transform** CSV / TSV / TAB files.

This is an extended native Lazarus/FPC rewrite of the original
[csvtab-wlx](https://github.com/little-brother/csvtab-wlx) by *little-brother*.
It keeps the fast Lister workflow, but turns CSV viewing into a compact table
workbench: open messy files, inspect them, filter and sort them, edit real CSV
cells, try column transformations, and copy or export exactly what you need.

---

## Feature Highlights

### Open messy CSV files with confidence

csvtab is built for the kind of CSV files that are almost, but not quite,
regular.

* Detects ANSI, UTF-8, UTF-16LE and UTF-16BE, including BOM handling.
* Detects common delimiters automatically: comma, semicolon, TAB, pipe and colon.
* Honors an Excel-style first line such as `sep=;` (case-insensitive, optional
  BOM, exactly one separator character). It overrides the INI delimiter and
  automatic detection, stays hidden in every comment mode, and leaves the next
  line available as the table header.
* Supports quoted CSV, doubled quotes, multiline cells and empty trailing cells.
* Detects the effective column count from a configurable sample and treats short
  preamble rows before the first full-width row as comments.
* Skips leading comment/preamble rows in Auto/Hidden mode, including `#`,
  `sep=` and single-semicolon comment lines.
* Reports the configured size limit and real file size when a file is too large
  to load.

### Fast table view

* Native owner-data ListView for large tables.
* Fast initial loading with original file bytes and a quote-aware row index,
  rather than allocating every cell in advance. A bounded row cache decodes
  the cells needed for display and samples; it does not expand the whole table
  in the background. Unusual encoding/parser cases retain the existing parser.
* Filtering, stable natural sorting and transformation work directly with indexed
  data. Single-column scans decode only the requested field, and sorting builds
  its keys once rather than decoding values on every comparison.
* The first edit or structural change builds the existing source-preserving
  editable model. Large files can therefore take additional time and memory on
  their first write operation. Quoting, BOM, encoding and line endings remain
  preserved by the existing patch/save path.
* Column widths are calculated before the grid is shown, so the first paint uses
  the final widths.
* Optional line-number column sized from the largest visible row number.
* Alternating row colours, current-cell highlight, dark mode and configurable
  fonts/colours.
* DPI-aware layout: filter row, status bar, transform sidebar, padding and
  fonts scale with the active monitor.
* Header text is bold, column dragging is disabled, and header/filter columns
  stay aligned during horizontal scrolling and column resizing.

### Filters that stay responsive

* One filter field per data column, placed above the header.
* Filter expressions support text matching and the existing comparison
  operators.
* Filter changes are debounced: the table is updated **250 ms after the last
  keystroke**, which keeps larger files much smoother while typing.
* `Esc` inside a filter field only returns focus to the table; it does not close
  the Lister.

### Navigate like a spreadsheet

* Arrow keys move the current cell up, down, left and right.
* **PgUp/PgDown** and arrow keys share the current row in either order;
  paging keeps the current column.
* At the visible window edge, the table scrolls by row or column as needed.
* **Ctrl+Arrow** jumps to the first/last row or first/last visible column.
* Hidden columns are skipped during horizontal navigation.

### Edit real CSV data safely

Edit mode turns the viewer into a careful CSV editor without throwing away the
original file structure.

* Toggle **Edit mode** with **Ctrl+E** or **Ctrl+R**.
* Start editing the selected cell with **Enter**, **F2** or double-click.
* **Enter** accepts an active edit, **Esc** cancels it.
* Insert a new empty row below the current row from the context menu.
* Delete selected rows with **Ctrl+X** or the context menu.
* Delete a column from the header/context menu in Edit mode.
* Save with **Ctrl+S**. Saving is atomic and preserves encoding, BOM, delimiter
  and comment handling as far as possible.
* Selecting a delimiter in the status bar converts the current in-memory CSV,
  preserves pending edits, updates an existing `sep=` line and adjusts quoting.
  The file is written only on **Ctrl+S**. Transformation exports also update an
  existing directive; neither operation adds one to a file that did not have it.
* Dirty files are marked in the status bar and prompt before close or reload.

### Transform columns without touching the original

**Transform mode** opens a sidebar for trying column operations as a live,
read-only preview. The source file is not changed until you explicitly export.

| Area | What it does |
|------|--------------|
| Ordering | Move columns up and down |
| Columns | Add, remove or rename columns |
| Values | Set all cells, fill only empty cells, enumerate rows, set number formats |
| Presets | Load and save transformations as JSON |
| Export | Write the transformed result to a new CSV with selectable delimiter |

Transform JSON files are compatible with the bundled Python workflow, so
repeatable cleanup jobs can be saved and reused.

### Status bar control

The status bar is interactive. Encoding and comment options reload the file;
manual delimiter choices convert the current document and mark it as modified.
`Auto` keeps the current data and returns to automatic delimiter selection for
future loads (an existing `sep=` directive always takes precedence):

| Segment | Options |
|---------|---------|
| Encoding | ANSI, UTF-8, UTF-16LE, UTF-16BE |
| Delimiter | Auto, comma, semicolon, pipe, TAB, colon |
| Comments | Auto, Parse normally, Do not parse, Hide |
| Rows | Visible/total row count |
| Position | Current `row:column`, edit/dirty/transform state |

The Comments segment also shows how many comment/preamble rows are hidden in
the current mode.

### Search, copy and URLs

* Total Commander search is supported via **F3** and **Shift+F3** for forward
  and backward search.
* **C** copies the current cell.
* **Shift+C** copies selected rows, respecting hidden columns and column order.
* **Ctrl+C** copies the current column if configured that way.
* The row-copy delimiter is configurable and defaults to TAB.
* **Alt+click** opens URLs found in cells.

### Decimal alignment

With `decimal-align=1` (default), numeric-looking columns are sampled and drawn
with decimal alignment:

* floats using `.` and `,` are aligned at the decimal separator;
* integer cells in mixed integer/float columns align directly before the decimal
  anchor;
* integer cells share the column's numeric anchor;
* nonnumeric columns keep normal text layout.

Configured unit suffixes are recognized for **alignment only**. The default is:

```ini
numeric-units=%,kg,m,km/h,°,Hz,MHz
```

For example, `75%`, `12.5 MHz` and `-3,25 Hz` align their numeric part while
keeping the suffix and its spacing. The list is comma-separated and
case-sensitive (`MHz` is not `mHz`). Set `numeric-units=` to disable units, or
`decimal-align=0` to disable numeric alignment entirely. Classification still
uses `max-column-samples`. Data, copying, saving, filtering and sorting are
unchanged; suffixed values retain natural text sorting, not unit conversion or
guaranteed numeric ordering of decimal values.

---

## Right-click Menu

The grid context menu keeps the everyday actions close to the table:

| Item | Shortcut |
|------|----------|
| Copy cell | C |
| Copy row(s) | Shift+C |
| Copy column | Ctrl+C |
| Insert row below | Edit mode only |
| Delete row(s) | Ctrl+X, Edit mode only |
| Delete column | Edit mode only |
| Hide column | Ctrl+click header |
| Adjust all column widths | Ctrl+H |
| Show all columns | Ctrl+Space |
| Filters | toggle filter row |
| Header row | toggle first row as header |
| Edit mode | Ctrl+E |
| Transform mode | Ctrl+T |
| Save | Ctrl+S |
| Show line numbers | toggle line-number column |
| Dark theme | toggle dark colours |

---

## Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| Arrow keys | Move current cell up/down/left/right |
| Ctrl+Arrow keys | Jump to first/last row or first/last visible column |
| Enter / F2 / Double-click | Edit the current cell in Edit mode |
| Enter / Esc | Accept / cancel the active cell edit |
| Ctrl+E or Ctrl+R | Toggle Edit mode |
| Ctrl+T | Toggle Transform mode |
| Ctrl+X | Delete selected row(s) in Edit mode |
| Ctrl+S | Save the file |
| C | Copy current cell |
| Shift+C | Copy selected row(s) |
| Ctrl+C | Copy current column, depending on `copy-column` |
| Ctrl+Space | Show all columns |
| Ctrl+H | Measure every visible row and adjust all visible columns to their full required width |
| Ctrl++ / Ctrl+- | Increase / decrease font size |
| Ctrl+Mouse wheel | Zoom font |
| Alt+Click | Open URL in a cell |
| Click header | Sort column; third click restores original order |
| Ctrl+Click header | Hide column |
| F3 / Shift+F3 | Search forward / backward via Total Commander |
| Esc | Close Lister; inside filter, return focus to table |
| 1..8, N, P, Q | Forwarded to Total Commander according to INI options |
| F1 | Open the original wiki |

---

## Installation

1. Build the plugin with Free Pascal / Lazarus to produce `csvtab.wlx` and
   `csvtab.wlx64`.
2. In Total Commander open **Configuration -> Options -> Plugins -> Lister
   plugins (WLX) -> Configure -> Add**, then point it at the `.wlx` or `.wlx64`
   file. Total Commander can also install the packaged zip automatically via
   `pluginst.inf`.
3. Open any CSV/TSV/TAB file in Lister with **F3** or in the Quick View Panel
   with **Ctrl+Q**.

---

## Configuration

Settings live in `csvtab.ini` next to the plugin. A few common options:

| Key | Meaning |
|-----|---------|
| `font` / `font-size` / `font-weight` | Grid font |
| `language` | `Auto` or a language code such as `en`, `de`, `cs`, or `fr`; legacy language names remain supported |
| `start-mode` | Start in `default`, `editor` or `transformer` mode |
| `header-row` | Treat the first row as a header (0/1) |
| `filter-row` | Show the per-column filter row (0/1) |
| `show-line-numbers` | Show the row-number column on the left (0/1) |
| `decimal-align` | Align mixed integers/floats at the decimal position (0/1, default 1) |
| `numeric-units` | Alignment-only suffixes, default `%,kg,m,km/h,°,Hz,MHz`; empty disables units |
| `theme-mode` | `tc` follows Total Commander, `light`/`dark` force a fixed theme |
| `dark-theme` | Legacy fallback when `theme-mode` is missing (0/1) |
| `skip-comments` | 0 parse / 1 keep comment as one cell / 2 hide / 3 auto-hide leading comments and blank rows |
| `default-column-delimiter` | Force a CSV delimiter; empty means auto-detect |
| `column-delimiter` | Delimiter used when copying rows (default TAB) |
| `trim-values` | Trim leading/trailing spaces and tabs (0/1) |
| `max-file-size` | Size limit in bytes (0 = unlimited) |
| `allColumnsToMaxWidth` | Measure every visible row and use each column's full required width, bypassing automatic width limits (0/1) |
| `max-column-samples` | Rows sampled for width, used-column and numeric detection |
| `max-column-width` | Maximum automatic column width; with exactly two columns it limits only the first column |
| `copy-column` | Ctrl+C copies cell (0) or column (1) |
| `filter-case-sensitive` | Case-sensitive filtering (0/1) |
| `disable-num-keys` | Do not forward number keys to Total Commander (0/1) |
| `disable-np-keys` | Do not forward N/P to Total Commander (0/1) |

GUI translations are UTF-8 files in the `language` directory. The value of
`language` maps directly to `<code>.lng`, so adding `fr.lng` makes
`language=fr` available without changing the plugin. Regional codes first try
their complete name and then the base language (`fr-CA` -> `fr-ca.lng`, then
`fr.lng`). `Auto` follows Total Commander's language when a matching catalog
exists and otherwise uses the Windows UI language. The included catalogs are
English (`en`), German (`de`), Czech (`cs`), Ukrainian (`uk`), and Russian
(`ru`). Missing files or individual keys fall back to the complete English
catalog built into the plugin.
| `exit-by-q` | Forward Q as close/exit key to Total Commander (0/1) |

All light- and dark-theme colours are configurable as RGB integers; see the
comments in `csvtab.ini` for the full list.

---

## Notes

* `default-column-delimiter` controls the delimiter used for parsing when set.
  `column-delimiter` controls the delimiter used when copying rows.
* `Comments: Auto` hides only the leading preamble/comment block. Later comment
  lines inside the table remain visible.
* `Comments: Hidden` hides comment lines and blank lines.
* The initial focus is placed on the table only in a separate Lister window; in
  Quick View the focus remains with Total Commander.

---

## Credits

Based on [csvtab-wlx](https://github.com/little-brother/csvtab-wlx) by
*little-brother*. Original project licensed under its respective terms; see
`LICENSE`.
